package com.deepak.porterRequestApplication.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBUtil {
	
	public static Connection getConnection()
	{
		Connection con=null;
		try{  
			//step1 load the driver class  
			Class.forName("com.mysql.jdbc.Driver");  
			  
			//step2 create  the connection object  
			con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3307/paymentbill","root","root");  
			  
			//step3 create the statement object  
			//Statement stmt=con.createStatement();  
			  
			//step5 close the connection object  
			//con.close();  
			  
			}catch(Exception e){ System.out.println(e);}
		return con;  
			  
			}

}
