package com.deepak.porterRequestApplication.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.deepak.porterRequestApplication.bean.PorterJobDetails;
import com.deepak.porterRequestApplication.bean.UserDetails;

public class PorterRequestDao {

	//Add porter Request Detail
	public static int addRequestDetail(String pickupLocation, String deliveryLocation,String time,String amount)
	{
	Connection con=null;
	String status="Pending";
	int i=0;
	try{  
		  
		con= DBUtil.getConnection();
		PreparedStatement stmt = null;
		//step3 create the statement object  
		stmt=con.prepareStatement("insert into paymentbill.Porter_jobs (pickUpLocation,deliveryLocation,amount,time,jobstatus) values(?,?,?,?,?)");  
		stmt.setString(1,pickupLocation);
		stmt.setString(2,deliveryLocation); 
		stmt.setString(3,amount);	
		stmt.setString(4,time);
		stmt.setString(5, status);
		i=stmt.executeUpdate();  
		System.out.println(i+" records inserted");  
		  stmt.close();
		con.close();  
		  
		}catch(Exception e){ System.out.println(e);}
	return i;
		  
		} 
	
	//Add porter User Detais.
	public static int addPorterDetails(String userName,String password, String address,String contact )
	{
		Connection con=null;
		int i=0;
		try{  
			con= DBUtil.getConnection();  
			  
			//step3 create the statement object
			PreparedStatement stmt = null;
			stmt=con.prepareStatement("insert into Porter_User (userName,pass,address,contact) values(?,?,?,?)");  
	
			stmt.setString(1,userName);  
			stmt.setString(2,password);
			stmt.setString(3,address);
			stmt.setString(4,contact);
			  
			i=stmt.executeUpdate();  
			System.out.println(i+" records inserted");  
			stmt.close();
			con.close();  
			  
			}catch(Exception e){ System.out.println(e);}
		return i;
			  
	}
	
	//Validate Login details
	public static boolean validatePorter(String userName, String password)
	{
	Connection con=null;
	boolean flag=false;
	try{  
		
		con= DBUtil.getConnection();
		PreparedStatement ps=con.prepareStatement(  
				"select * from Porter_User where userName=? and pass=?");  
				ps.setString(1,userName);  
				ps.setString(2,password);  
				      
				ResultSet rs=ps.executeQuery();  
				flag=rs.next();  
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ e.printStackTrace();}
	return flag;
		  
		} 

	// Get Porter User Details
	public static UserDetails getPorterDetail()
	{
		UserDetails userDetails=new UserDetails();
	Connection con=null;
	try{  
		con= DBUtil.getConnection();
		  
		//step3 create the statement object  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select * from Porter_User");  
		while(rs.next())  
		{
			
			userDetails.setPorterId(rs.getString(1));
			userDetails.setUserName(rs.getString(2));
			userDetails.setPassword(rs.getString(3));
			userDetails.setAddress(rs.getString(4));
			userDetails.setContact(rs.getString(5));
			
		  
		}
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ System.out.println(e);}
	return userDetails;
		  
		} 
	
	//Get completed request job details of porter.
	public static ArrayList<PorterJobDetails> getCompletedRequestJobDetail()
	{
		ArrayList<PorterJobDetails> porterJobDetailsList = new ArrayList<PorterJobDetails>();
		
	Connection con=null;
	try{  
		con= DBUtil.getConnection(); 
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select * from Porter_jobs where jobstatus='Completed'");  
		while(rs.next())  
		{  
		PorterJobDetails porterJobDetails=new PorterJobDetails();
		porterJobDetails.setJobId(rs.getString(1));
		porterJobDetails.setPickupLocation(rs.getString(2));
		porterJobDetails.setDeliveryLocation(rs.getString(3));	
		porterJobDetails.setAmount(rs.getString(4));
		porterJobDetails.setTimeToReach(rs.getString(5));
		porterJobDetails.setStatus(rs.getString(6));
		porterJobDetails.setAssignPorter(rs.getString(7));	
		porterJobDetailsList.add(porterJobDetails);
		}
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ System.out.println(e);}
	return porterJobDetailsList;
		  
		} 
	
	//Get pending request job details of porter.
		public static ArrayList<PorterJobDetails> getPendingRequestJobDetail()
		{
			ArrayList<PorterJobDetails> porterJobDetailsList = new ArrayList<PorterJobDetails>();
			
		Connection con=null;
		try{  
			con= DBUtil.getConnection(); 
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select * from Porter_jobs where jobstatus='Pending'");  
			while(rs.next())  
			{  
			PorterJobDetails porterJobDetails=new PorterJobDetails();
			porterJobDetails.setJobId(rs.getString(1));
			porterJobDetails.setPickupLocation(rs.getString(2));
			porterJobDetails.setDeliveryLocation(rs.getString(3));	
			porterJobDetails.setAmount(rs.getString(4));
			porterJobDetails.setTimeToReach(rs.getString(5));
			porterJobDetails.setStatus(rs.getString(6));
			porterJobDetails.setAssignPorter(rs.getString(7));	
			porterJobDetailsList.add(porterJobDetails);
			}
			//step5 close the connection object  
			con.close();  
			  
			}catch(Exception e){ System.out.println(e);}
		return porterJobDetailsList;
			  
			} 

}
