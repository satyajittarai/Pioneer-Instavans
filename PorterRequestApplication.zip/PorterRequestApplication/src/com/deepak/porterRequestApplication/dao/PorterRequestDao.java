package com.deepak.porterRequestApplication.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.deepak.porterRequestApplication.bean.PorterJob;
import com.deepak.porterRequestApplication.bean.PorterUser;

public class PorterRequestDao {

	//Add porter Request Detail
	public static int addRequestDetail(String pickupLocation, String deliveryLocation,String time,String amount)
	{
	Connection con=null;
	String status="Pendding";
	int i=0;
	try{  
		  
		con= DBUtil.getConnection();
		PreparedStatement stmt = null;
		//step3 create the statement object  
		stmt=con.prepareStatement("insert into paymentbill.Porter_jobs (pickUpLocation,deliveryLocation,amount,time,jobstatus) values(?,?,?,?,?)");  
		stmt.setString(1,pickupLocation);
		stmt.setString(2,deliveryLocation); 
		stmt.setString(3,amount);	
		stmt.setString(4,time);
		stmt.setString(5, status);
		i=stmt.executeUpdate();  
		System.out.println(i+" records inserted");  
		  stmt.close();
		con.close();  
		  
		}catch(Exception e){ System.out.println(e);}
	return i;
		  
		} 
	
	//Add porter User Detais.
	public static int addPorterDetails(String userName,String password, String address,String contact )
	{
		Connection con=null;
		int i=0;
		try{  
			con= DBUtil.getConnection();  
			  
			//step3 create the statement object
			PreparedStatement stmt = null;
			stmt=con.prepareStatement("insert into Porter_User (userName,pass,address,contact) values(?,?,?,?)");  
	
			stmt.setString(1,userName);  
			stmt.setString(2,password);
			stmt.setString(3,address);
			stmt.setString(4,contact);
			  
			i=stmt.executeUpdate();  
			System.out.println(i+" records inserted");  
			stmt.close();
			con.close();  
			  
			}catch(Exception e){ System.out.println(e);}
		return i;
			  
	}
	
	//Validate Login details
	public static boolean validatePorter(String userName, String password)
	{
	Connection con=null;
	boolean flag=false;
	try{  
		
		con= DBUtil.getConnection();
		PreparedStatement ps=con.prepareStatement(  
				"select * from Porter_User where userName=? and pass=?");  
				ps.setString(1,userName);  
				ps.setString(2,password);  
				      
				ResultSet rs=ps.executeQuery();  
				flag=rs.next();  
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ e.printStackTrace();}
	return flag;
		  
		} 

	// Get Porter User Details
	public static PorterUser getPorterDetail()
	{
		PorterUser porterUser=new PorterUser();
	Connection con=null;
	try{  
		con= DBUtil.getConnection();
		  
		//step3 create the statement object  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select * from Porter_User");  
		while(rs.next())  
		{
			
			porterUser.setPorterId(rs.getString(1));
			porterUser.setUserName(rs.getString(2));
			porterUser.setPassword(rs.getString(3));
			porterUser.setAddress(rs.getString(4));
			porterUser.setContact(rs.getString(5));
			
		System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
		}
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ System.out.println(e);}
	return porterUser;
		  
		} 
	
	//Get request job details of porter.
	public static PorterJob getRequestJobDetail()
	{
		PorterJob porterJob=new PorterJob();
	Connection con=null;
	try{  
		con= DBUtil.getConnection(); 
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select * from Porter_jobs");  
		while(rs.next())  
		{
		System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
		porterJob.setJobId(rs.getString(1));
		porterJob.setLocation(rs.getString(2));
		porterJob.setTimeToReach(rs.getString(3));
		porterJob.setAmount(rs.getString(4));
		porterJob.setStatus(rs.getString(5));
		porterJob.setAssignPorter(rs.getString(6));	
		}
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ System.out.println(e);}
	return porterJob;
		  
		} 
}
