package com.deepak.porterRequestApplication.bean;

public class PorterJobDetails {
	String jobId;
	String pickupLocation;
	String deliveryLocation;
	String amount;
	String timeToReach;
	String status;
	String assignPorter;
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getPickupLocation() {
		return pickupLocation;
	}
	public void setPickupLocation(String pickupLocation) {
		this.pickupLocation = pickupLocation;
	}
	public String getDeliveryLocation() {
		return deliveryLocation;
	}
	public void setDeliveryLocation(String deliveryLocation) {
		this.deliveryLocation = deliveryLocation;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getTimeToReach() {
		return timeToReach;
	}
	public void setTimeToReach(String timeToReach) {
		this.timeToReach = timeToReach;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAssignPorter() {
		return assignPorter;
	}
	public void setAssignPorter(String assignPorter) {
		this.assignPorter = assignPorter;
	}
	
}
