package com.deepak.porterRequestApplication.bean;

public class UserDetails {
	String PorterId;
	String UserName;
	String password;
	String address;
	String contact;
	public String getPorterId() {
		return PorterId;
	}
	public void setPorterId(String porterId) {
		PorterId = porterId;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
}
