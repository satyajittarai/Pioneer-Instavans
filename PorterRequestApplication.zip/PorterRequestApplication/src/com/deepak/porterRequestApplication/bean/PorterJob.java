package com.deepak.porterRequestApplication.bean;

public class PorterJob {
	String jobId;
	String location;
	String timeToReach;
	String amount;
	String status;
	String assignPorter;
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTimeToReach() {
		return timeToReach;
	}
	public void setTimeToReach(String timeToReach) {
		this.timeToReach = timeToReach;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAssignPorter() {
		return assignPorter;
	}
	public void setAssignPorter(String assignPorter) {
		this.assignPorter = assignPorter;
	}
}
