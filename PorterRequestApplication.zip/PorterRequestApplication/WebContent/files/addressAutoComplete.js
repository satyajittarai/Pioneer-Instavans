/**
 * Created by Hardik on 7/10/2015.
 */
jQuery(document).ready(function () {
    initialize();
    //google.maps.event.addDomListener(window, 'load', initialize);

});

function initialize() {
    
    var inputPickUp = document.getElementById('pick-input');
    var autocompletePickUp = new google.maps.places.Autocomplete(inputPickUp);
    google.maps.event.addListener(autocompletePickUp, 'place_changed', function () {
        var placePickUp = autocompletePickUp.getPlace();
        var latPickUp = autocompletePickUp.getPlace().geometry.location["A"];
        var lngPickUp = autocompletePickUp.getPlace().geometry.location["F"];
        $("#pick-input-hidden-lat").val(latPickUp);
        $("#pick-input-hidden-lng").val(lngPickUp);
        $("#pick-input").blur();
        //console.log("placePickUp: " + $("#pick-input").val());
        //console.log("latPickUp: " + latPickUp);
        //console.log("lngPickUp: " + lngPickUp);

    });

    var inputDelivery = document.getElementById('delivery');
    var autocompleteDelivery = new google.maps.places.Autocomplete(inputDelivery);
    google.maps.event.addListener(autocompleteDelivery, 'place_changed', function () {
        var placeDelivery = autocompleteDelivery.getPlace();
        var latDelivery = autocompleteDelivery.getPlace().geometry.location["A"];
        var lngDelivery = autocompleteDelivery.getPlace().geometry.location["F"];
        $("#delivery-input-hidden-lat").val(latDelivery);
        $("#delivery-input-hidden-lng").val(lngDelivery);
        $("#delivery").blur();
        //console.log("placeDelivery: " + $("#delivery").val());
        //console.log("latDelivery: " + latDelivery);
        //console.log("lngDelivery: " + lngDelivery);
    });
}

