package instavan.org.porterappnew;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;
import java.util.zip.Inflater;

/**
 * Created by machine on 06-03-2016.
 */
public class CustomAdapter extends ArrayAdapter {
List<AvJobBeans> list ;
    public CustomAdapter(Context context, int resource,List jobList) {
        super(context, resource);
        list=jobList;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.list_item_view, parent, false);
        }
        TextView  textView= (TextView) row.findViewById(R.id.textView3);
      AvJobBeans avJobBeans= (AvJobBeans) list.get(0);
        textView.setText("Location : "+avJobBeans.getLocation());
        TextView textView1= (TextView) row.findViewById(R.id.textView4);
        textView1.setText("Amount Qouted : "+avJobBeans.getAmount());
        TextView textView2= (TextView) row.findViewById(R.id.textView5);
        textView2.setText("Time to arrive (in mins) : " +avJobBeans.getTimeToReach());

        return row;
    }
}
