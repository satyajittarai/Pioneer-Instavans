package instavan.org.porterappnew;

import android.content.Context;
import android.os.AsyncTask;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TabbedActivity extends AppCompatActivity {

    private List avJobList=new ArrayList();
    private CustomAdapter  customAdapter;
    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        new AvaJobs().execute();
      //  customAdapter=new CustomAdapter(getApplicationContext(),R.layout.list_item_view);
        setContentView(R.layout.activity_tabbed);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);
     }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tabbed, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            return PlaceholderFragment.newInstance(position + 1);
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 3;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "SECTION 1";
                case 1:
                    return "SECTION 2";
                case 2:
                    return "SECTION 3";
            }
            return null;
        }
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public PlaceholderFragment() {
            Context context=null;

        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_tabbed, container, false);
           if(getArguments().getInt(ARG_SECTION_NUMBER)==1){
               ListView listView= (ListView) rootView.findViewById(R.id.listView);
               List values=new ArrayList();
               values.add("amit");
               values.add("shah");
               values.add("amit");
               values.add("shah");
               values.add("amit");
               values.add("shah");
               values.add("amit");
               values.add("shah");

               ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                       android.R.layout.simple_list_item_1, android.R.id.text1, values);
               Context context=new TabbedActivity();
              // CustomAdapter  customAdapter=new CustomAdapter(context,R.layout.list_item_view);
               //listView.setAdapter(customAdapter);
           } else if(getArguments().getInt(ARG_SECTION_NUMBER)==2){
               ListView listView= (ListView) rootView.findViewById(R.id.listView);
               List values=new ArrayList();
               values.add("kapil");
               values.add("sharma");
               ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                       android.R.layout.simple_list_item_1, android.R.id.text1, values);
               listView.setAdapter(adapter);
           }

            /*TextView textView = (TextView) rootView.findViewById(R.id.section_label);
            ListView listView= (ListView) rootView.findViewById(R.id.listView);
            List values=new ArrayList();
            values.add("amit");
            values.add("shah");
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                    android.R.layout.simple_list_item_1, android.R.id.text1, values);
            listView.setAdapter(adapter);
            textView.setText(getString(R.string.section_format, getArguments().getInt(ARG_SECTION_NUMBER)));*/
            return rootView;
        }
    }

    private class AvaJobs extends AsyncTask{

        @Override
        protected Object doInBackground(Object[] params) {
            List list=new ArrayList();
            try {
                URL url=new URL("http://192.168.6.228:8080/PorterSystem/AvailableJobs");
                HttpURLConnection urlConnection=(HttpURLConnection)url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);
                String line;
                BufferedReader br=new BufferedReader(new InputStreamReader(url.openStream()));
               // AvJobBeans avJobBeans;
                StringBuilder builder=new StringBuilder();

                while((line=br.readLine())!=null){
                       builder.append(line);
                }
                JSONObject jsonObject=new JSONObject(builder.toString());

                for(int i=0;i<jsonObject.length();i++){
                    JSONObject jsonObject1=new JSONObject(jsonObject.get(String.valueOf(i)).toString());
                    AvJobBeans avJobBeans1=new AvJobBeans();
                    avJobBeans1.setAmount(jsonObject1.getString("AMOUNT"));
                    avJobBeans1.setLocation(jsonObject1.getString("LOCATION"));
                    avJobBeans1.setTimeToReach(jsonObject1.getString("TIME_TO_REACH"));
                    avJobBeans1.setStatus("STATUS");
                     avJobList.add(avJobBeans1);

                    Log.v("amit shah", jsonObject.get(String.valueOf(i)).toString());
                }

              //  JSONTokener jsonTokener=new JSONTokener(builder.toString());
               // JSONArray jsonArray=new JSONArray(jsonTokener);
                //Log.v("amit shah", jsonArray.getJSONObject(0).toString());

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


            return list;
        }

        @Override
        protected void onPostExecute(Object o) {
            List  list= (List) o;

        }
    }








}
