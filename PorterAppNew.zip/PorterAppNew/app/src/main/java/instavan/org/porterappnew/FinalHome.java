package instavan.org.porterappnew;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class FinalHome extends AppCompatActivity {

    Button availJobs;
    Button allJobs;
    private ListView listView;
    private List<AvJobBeans> avJobList;
    CustomAdapter customAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_final_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
           availJobs= (Button) findViewById(R.id.button);
           allJobs=(Button)findViewById(R.id.button2);
        listView= (ListView) findViewById(R.id.listView2);
        availJobs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AvaJobs().execute();
            }
        });





        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, final View view, final int position, long id) {
              //  Toast.makeText(getApplicationContext(),"clicked",2000).show();
              //

                final AlertDialog selectAction=new AlertDialog.Builder(FinalHome.this).create();
                selectAction.setMessage("Do you want to lock this job");
                selectAction.setButton(-1, "YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),avJobList.get(position).getJobId(),2000).show();
                    }
                });
              selectAction.show();

            }
        });
        }


    private class AvaJobs extends AsyncTask {

        @Override
        protected Object doInBackground(Object[] params) {
            List list = new ArrayList();
            avJobList = new ArrayList();
            try {

                URL url = new URL("http://192.168.6.228:8080/PorterSystem/AvailableJobs");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
                // AvJobBeans avJobBeans;
                StringBuilder builder = new StringBuilder();

                while ((line = br.readLine()) != null) {
                    builder.append(line);
                }
                JSONObject jsonObject = new JSONObject(builder.toString());

                for (int i = 0; i < jsonObject.length(); i++) {
                    JSONObject jsonObject1 = new JSONObject(jsonObject.get(String.valueOf(i)).toString());
                    AvJobBeans avJobBeans1 = new AvJobBeans();
                    avJobBeans1.setAmount(jsonObject1.getString("AMOUNT"));
                    avJobBeans1.setLocation(jsonObject1.getString("LOCATION"));
                    avJobBeans1.setTimeToReach(jsonObject1.getString("TIME_TO_REACH"));
                    avJobBeans1.setStatus("STATUS");
                    avJobList.add(avJobBeans1);

                    Log.v("amit shah", jsonObject.get(String.valueOf(i)).toString());
                }

                //  JSONTokener jsonTokener=new JSONTokener(builder.toString());
                // JSONArray jsonArray=new JSONArray(jsonTokener);
                //Log.v("amit shah", jsonArray.getJSONObject(0).toString());

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


            return list;
        }

        @Override
        protected void onPostExecute(Object o) {
            Log.v("on post","post");

            customAdapter =new CustomAdapter(getApplicationContext(),R.layout.list_item_view,avJobList);
            listView.setAdapter(customAdapter);

        }
    }

    private class completedJobs extends AsyncTask{

        @Override
        protected Object doInBackground(Object[] params) {
            List list = new ArrayList();
            avJobList = new ArrayList();
            try {

                URL url = new URL("http://192.168.6.228:8080/PorterSystem/CompletedJobs");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
                // AvJobBeans avJobBeans;
                StringBuilder builder = new StringBuilder();

                while ((line = br.readLine()) != null) {
                    builder.append(line);
                }
                JSONObject jsonObject = new JSONObject(builder.toString());

                for (int i = 0; i < jsonObject.length(); i++) {
                    JSONObject jsonObject1 = new JSONObject(jsonObject.get(String.valueOf(i)).toString());
                    AvJobBeans avJobBeans1 = new AvJobBeans();
                    avJobBeans1.setAmount(jsonObject1.getString("AMOUNT"));
                    avJobBeans1.setLocation(jsonObject1.getString("LOCATION"));
                    avJobBeans1.setTimeToReach(jsonObject1.getString("TIME_TO_REACH"));
                    avJobBeans1.setStatus("STATUS");
                    avJobList.add(avJobBeans1);

                    Log.v("amit shah", jsonObject.get(String.valueOf(i)).toString());
                }


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


            return avJobList;
        }
    }
    private class updateJobs extends AsyncTask{

        @Override
        protected Object doInBackground(Object[] params) {
            return null;
        }
    }
}

